# Muxy Extension JavaScript Library

The Muxy Extensions JS library provides easy access to Muxy's powerful backend architecture.

The extension provides four main sections of functionality: Data Storage, an Event Manager, a Twitch Client and a Google Analytics system.

See also:

[Overlay App Rig](https://github.com/muxy/overlay-app-rig)

[Muxy Extensions Rig](https://github.com/muxy/extensions-rig)

## Change Log
 - [Change Log](CHANGELOG.md)
