import Muxy from './muxy';

module.exports = Muxy;
